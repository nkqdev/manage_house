package com.example.manage_house

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
